import { removeElementsByTag } from './utils.js';

export function removeFeedBar() {
    removeElementsByTag("ytd-feed-filter-chip-bar-renderer");
}
