import { removeElementsByClass } from './utils.js';

export function removeEndPromotion() {
    removeElementsByClass("ytp-ce-element");
}
