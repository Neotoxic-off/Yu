import { removeElementsByTag } from './utils.js';

export function removeVideoPreview() {
    removeElementsByTag("ytd-video-preview");
}
